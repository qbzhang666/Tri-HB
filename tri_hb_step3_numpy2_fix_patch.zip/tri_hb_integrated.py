"""
Integrated Tri-HB Streamlit app.

Run with:
    streamlit run tri_hb_integrated.py

This file keeps the existing specialist apps available while adding one
navigation shell and an experimental SHPB/Tri-HB data-reduction workspace.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st


APP_DIR = Path(__file__).resolve().parent


st.set_page_config(
    page_title="Tri-HB Integrated",
    page_icon="Tri-HB",
    layout="wide",
    initial_sidebar_state="expanded",
)


def strip_page_config(source: str) -> str:
    """Remove st.set_page_config blocks from legacy Streamlit scripts."""
    lines = source.splitlines()
    kept: list[str] = []
    skipping = False
    depth = 0

    for line in lines:
        if not skipping and "st.set_page_config(" in line:
            skipping = True
            depth = line.count("(") - line.count(")")
            if depth <= 0:
                skipping = False
            continue

        if skipping:
            depth += line.count("(") - line.count(")")
            if depth <= 0:
                skipping = False
            continue

        kept.append(line)

    return "\n".join(kept)


def run_legacy_app(filename: str) -> None:
    """Execute an existing app inside this integrated shell."""
    path = APP_DIR / filename
    source = strip_page_config(path.read_text(encoding="utf-8"))
    globals_dict = {
        "__file__": str(path),
        "__name__": "__main__",
    }
    exec(compile(source, str(path), "exec"), globals_dict)


def read_uploaded_table(uploaded_file) -> pd.DataFrame:
    name = uploaded_file.name.lower()
    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(uploaded_file)
    return pd.read_csv(uploaded_file)


def cumulative_trapezoid(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    out = np.zeros_like(y, dtype=float)
    if len(y) > 1:
        out[1:] = np.cumsum(0.5 * (y[1:] + y[:-1]) * np.diff(x))
    return out


def close_energy_budget(
    incident: np.ndarray,
    reflected_target: np.ndarray,
    transmitted_target: np.ndarray,
    absorbed_target: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Create monotonic reflected/transmitted/absorbed histories that do not exceed incident energy."""
    reflected = np.zeros_like(incident, dtype=float)
    transmitted = np.zeros_like(incident, dtype=float)
    absorbed = np.zeros_like(incident, dtype=float)

    for i in range(1, len(incident)):
        reflected[i] = reflected[i - 1]
        transmitted[i] = transmitted[i - 1]
        absorbed[i] = absorbed[i - 1]

        remaining = max(float(incident[i] - reflected[i] - transmitted[i] - absorbed[i]), 0.0)

        for target, history in (
            (absorbed_target, absorbed),
            (reflected_target, reflected),
            (transmitted_target, transmitted),
        ):
            requested = max(float(target[i] - history[i]), 0.0)
            addition = min(requested, remaining)
            history[i] += addition
            remaining -= addition

    return reflected, transmitted, absorbed


def choose_column(label: str, columns: Iterable[str], key: str, optional: bool = False) -> str | None:
    options = list(columns)
    if optional:
        options = ["None"] + options
    selected = st.selectbox(label, options, key=key)
    if selected == "None":
        return None
    return selected


def experimental_analysis_page() -> None:
    st.markdown("## Experimental Data Analysis")
    st.caption(
        "Reduce bar-gauge data into stress, strain, strain-rate and energy histories, "
        "or import already reduced stress-strain data for comparison."
    )

    with st.expander("Equations used by the reducer", expanded=False):
        st.markdown("**Symbols.** "
                    r"$E_b$ bar Young's modulus, $C_0=\sqrt{E_b/\rho_b}$ bar wave speed, "
                    r"$A_b$ bar cross-section, $A_s$, $L_s$ specimen area and length, "
                    r"$\varepsilon_I,\varepsilon_R,\varepsilon_T$ incident / reflected / transmitted bar strains.")

        st.markdown("**Specimen stress (three-wave average):**")
        st.latex(r"\sigma_s(t)=\frac{E_b A_b}{2 A_s}\,\bigl[\varepsilon_I(t)+\varepsilon_R(t)+\varepsilon_T(t)\bigr]")

        st.markdown("**Specimen stress (transmitted-wave only, assumes force equilibrium):**")
        st.latex(r"\sigma_s(t)=\frac{E_b A_b}{A_s}\,\varepsilon_T(t)")

        st.markdown("**Specimen strain rate and strain:**")
        st.latex(r"\dot\varepsilon_s(t)=\frac{C_0}{L_s}\,\bigl[\varepsilon_I(t)-\varepsilon_R(t)-\varepsilon_T(t)\bigr]")
        st.latex(r"\varepsilon_s(t)=\int_0^t \dot\varepsilon_s(\tau)\,\mathrm{d}\tau\quad\text{(trapezoidal)}")
        st.caption("Under perfect equilibrium $\\varepsilon_I+\\varepsilon_R=\\varepsilon_T$ the rate "
                   "simplifies to $\\dot\\varepsilon_s=-2C_0\\varepsilon_R/L_s$; this app uses the "
                   "general 3-wave form so pre-equilibrium data are still handled.")

        st.markdown("**Energies (per bar wave):**")
        st.latex(r"W_I(t)=E_b A_b C_0\!\int_0^t\!\varepsilon_I^2\,\mathrm{d}\tau,\quad "
                 r"W_R(t)=E_b A_b C_0\!\int_0^t\!\varepsilon_R^2\,\mathrm{d}\tau,\quad "
                 r"W_T(t)=E_b A_b C_0\!\int_0^t\!\varepsilon_T^2\,\mathrm{d}\tau")
        st.latex(r"W_{\rm abs}(t)=W_I(t)-W_R(t)-W_T(t)")
        st.caption("Units: $A_b\\,[\\mathrm{m}^2]\\cdot E_b\\,[\\mathrm{Pa}]\\cdot C_0\\,[\\mathrm{m/s}]"
                   "\\cdot\\int\\varepsilon^2\\,\\mathrm{d}t\\,[\\mathrm{s}]\\;=\\;\\mathrm{J}$.")

        st.markdown("**Symmetric-mode (Mode 4) energy folding** — opposing bar pair contributes both incident pulses; "
                    "both reflected bars are retained explicitly:")
        st.latex(r"W_I=E_b A_b C_0\!\int(\varepsilon_{I,+}^2+\varepsilon_{I,-}^2)\,\mathrm{d}t,\qquad "
                 r"W_R=E_b A_b C_0\!\int(\varepsilon_{R,+}^2+\varepsilon_{R,-}^2)\,\mathrm{d}t")

        st.markdown("**Absorbed energy from simulator stress–strain:**")
        st.latex(r"W_{\rm abs}(t)=\int_0^t \sigma_s(\tau)\,\dot\varepsilon_s(\tau)\,V_s\,\mathrm{d}\tau,"
                 r"\quad V_s=A_sL_s")
        st.caption("For simulator-derived histories, reflected, transmitted, and absorbed energies are closed against "
                   "the available incident energy so their cumulative sum never exceeds $W_I$.")

        st.markdown("**Direct stress–strain branch** — only unit conversion and rate estimate:")
        st.latex(r"\dot\varepsilon_s(t)=\frac{\mathrm{d}\varepsilon_s}{\mathrm{d}t}\quad(\text{central difference})")
        st.caption("Strain unit options: strain (1), percent ($\\div100$), microstrain ($\\times10^{-6}$). "
                   "Stress unit options: MPa (passthrough), Pa ($\\div10^6$). The compression-convention "
                   "selector applies a single global sign so the formulas above use the textbook "
                   "convention $\\varepsilon_I>0,\\;\\varepsilon_R<0,\\;\\varepsilon_T>0$ for a compression test.")

    latest_result = st.session_state.get("tri_hb_latest_result")
    latest_config = st.session_state.get("tri_hb_latest_config", {})
    default_bar_E_GPa = float(latest_config.get("bar_E", 210e9)) / 1e9
    default_bar_C0 = float(latest_config.get("bar_C0", 5172.0))
    default_bar_area_m2 = float(latest_config.get("bar_area", 0.050 * 0.050))
    default_specimen_size_mm = float(latest_config.get("specimen_size", 0.050)) * 1000.0
    default_specimen_length_mm = float(latest_config.get("specimen_length", latest_config.get("specimen_size", 0.050))) * 1000.0
    default_specimen_area_m2 = float(latest_config.get(
        "specimen_area",
        (default_specimen_size_mm * 1e-3) ** 2,
    ))

    # Defaults used by branches where duplicate geometry controls are hidden.
    bar_E_GPa = default_bar_E_GPa
    bar_C0 = default_bar_C0
    bar_d_mm = float(np.sqrt(4.0 * default_bar_area_m2 / np.pi) * 1000.0)
    square_bar = bool(np.isclose(default_bar_area_m2, 0.050 * 0.050, rtol=0.0, atol=1e-12))
    specimen_side_mm = default_specimen_size_mm
    specimen_length_mm = default_specimen_length_mm
    specimen_shape = "Square/cube"

    default_square_specimen_area = (default_specimen_size_mm * 1e-3) ** 2
    default_circular_specimen_area = np.pi * (default_specimen_size_mm * 1e-3 / 2.0) ** 2
    default_specimen_shape_index = 0
    if abs(default_specimen_area_m2 - default_circular_specimen_area) < abs(default_specimen_area_m2 - default_square_specimen_area):
        default_specimen_shape_index = 1

    with st.sidebar:
        st.header("Experimental analysis")
        source_options = []
        if latest_result is not None:
            source_options.append("Latest simulator result")
        source_options.extend(["Upload bar strain gauges", "Upload direct stress-strain"])
        data_source = st.radio(
            "Data source",
            source_options,
            help="Choose the source first; the column mapping and energy workflow update to match it.",
        )

        if data_source == "Upload bar strain gauges":
            st.divider()
            st.subheader("Specimen and bars")
            st.caption("Required only for reducing uploaded bar-gauge histories.")
            bar_E_GPa = st.number_input("Bar Young's modulus, Eb (GPa)", value=default_bar_E_GPa, min_value=1.0, step=5.0)
            bar_C0 = st.number_input("Bar wave speed, C0 (m/s)", value=default_bar_C0, min_value=1000.0, step=50.0)
            bar_d_mm = st.number_input("Round bar diameter (mm)", value=bar_d_mm, min_value=1.0, step=1.0)
            square_bar = st.checkbox("Use square 50 x 50 mm bar area", value=square_bar)
            specimen_side_mm = st.number_input("Specimen side/diameter (mm)", value=default_specimen_size_mm, min_value=1.0, step=1.0)
            specimen_length_mm = st.number_input("Specimen length (mm)", value=default_specimen_length_mm, min_value=1.0, step=1.0)
            specimen_shape = st.radio(
                "Specimen area",
                ["Square/cube", "Circular cylinder"],
                horizontal=True,
                index=default_specimen_shape_index,
            )
        elif data_source == "Latest simulator result":
            st.divider()
            st.caption(
                "Step 2 inherits the bar, specimen geometry, and material settings from Step 1 Test Design. "
                "Duplicate Specimen and bars inputs are hidden."
            )
        else:
            st.divider()
            st.caption(
                "Direct stress-strain files already contain reduced stress and strain, so bar/specimen inputs are not required."
            )

    use_simulator_result = data_source == "Latest simulator result"
    if data_source == "Upload bar strain gauges":
        analysis_mode = "Bar strain gauges"
    elif data_source == "Upload direct stress-strain":
        analysis_mode = "Direct stress-strain"
    else:
        analysis_mode = "Simulator result"

    uploaded = st.file_uploader(
        "Upload CSV or Excel data",
        type=["csv", "xlsx", "xls"],
        help="Expected columns include time and incident/reflected/transmitted strains, or direct stress and strain.",
        disabled=use_simulator_result,
    )

    if use_simulator_result and latest_result is not None:
        time_s = latest_result["time"]
        eps_i_pos = latest_result["epsI_x_pos"]
        eps_i_neg = latest_result.get("epsI_x_neg", np.zeros_like(eps_i_pos))
        eps_r_pos = latest_result.get("epsR_x_pos", np.zeros_like(eps_i_pos))
        eps_r_neg = latest_result.get("epsR_x_neg", np.zeros_like(eps_i_pos))
        eps_t = latest_result.get("epsT_x", np.zeros_like(eps_i_pos))

        sim_cfg = st.session_state.get("tri_hb_latest_config", latest_config)
        Ab = float(sim_cfg.get("bar_area", default_bar_area_m2))
        Eb = float(sim_cfg.get("bar_E", default_bar_E_GPa * 1e9))
        C0 = float(sim_cfg.get("bar_C0", default_bar_C0))
        As = float(sim_cfg.get("specimen_area", default_specimen_area_m2))
        Ls = float(sim_cfg.get("specimen_length", default_specimen_length_mm * 1e-3))
        sim_volume = As * Ls

        energy_i = Ab * Eb * C0 * cumulative_trapezoid(eps_i_pos**2 + eps_i_neg**2, time_s)
        energy_r_target = Ab * Eb * C0 * cumulative_trapezoid(eps_r_pos**2 + eps_r_neg**2, time_s)
        energy_t_target = Ab * Eb * C0 * cumulative_trapezoid(eps_t**2, time_s)
        absorbed_target = cumulative_trapezoid(latest_result["sig_x"] * latest_result["rate_x"] * sim_volume, time_s)
        energy_r, energy_t, absorbed = close_energy_budget(
            energy_i,
            energy_r_target,
            energy_t_target,
            absorbed_target,
        )
        out = pd.DataFrame(
            {
                "time_us": time_s * 1e6,
                "stress_MPa": latest_result["sig_x"] / 1e6,
                "strain": latest_result["eps_x"],
                "strain_rate_s-1": latest_result["rate_x"],
                "energy_incident_J": energy_i,
                "energy_reflected_J": energy_r,
                "energy_transmitted_J": energy_t,
                "energy_absorbed_J": absorbed,
            }
        )
        st.success(
            "Using the latest result from Test Design and Simulator. "
            "Peak stress and strain are read from the same Step 1 arrays."
        )
        df_raw = out.copy()
    elif uploaded is None:
        if analysis_mode == "Bar strain gauges":
            st.info("Upload bar-gauge data with time, incident strain, reflected strain, and transmitted strain columns.")
            example = pd.DataFrame(
                {
                    "time_us": np.linspace(0, 250, 6),
                    "eps_I_ue": [0, 50, 250, 120, 20, 0],
                    "eps_R_ue": [0, -10, -80, -40, -5, 0],
                    "eps_T_ue": [0, 20, 160, 90, 10, 0],
                }
            )
        else:
            st.info("Upload reduced stress-strain data with time, stress, and strain columns.")
            example = pd.DataFrame(
                {
                    "time_us": np.linspace(0, 250, 6),
                    "stress_MPa": [0, 35, 120, 165, 130, 80],
                    "strain_percent": [0, 0.08, 0.28, 0.52, 0.78, 0.95],
                }
            )
        st.dataframe(example, use_container_width=True)
        return
    else:
        df_raw = read_uploaded_table(uploaded)
        df_raw = df_raw.dropna(how="all")
        st.dataframe(df_raw.head(20), use_container_width=True)

        if df_raw.empty:
            st.error("The uploaded file did not contain any readable rows.")
            return

    if analysis_mode == "Simulator result":
        out = out.replace([np.inf, -np.inf], np.nan).dropna(subset=["time_us", "stress_MPa", "strain"])
        columns = list(df_raw.columns)
        col_map, col_plot = st.columns([0.9, 1.1])
        with col_map:
            st.subheader("Data source")
            st.write("Latest simulated axial stress-strain response.")
    else:
        columns = list(df_raw.columns)
        col_map, col_plot = st.columns([0.9, 1.1])

        with col_map:
            st.subheader("Column mapping")
            time_col = choose_column("Time column", columns, "exp_time")
            time_unit = st.selectbox("Time unit", ["microsecond", "second", "millisecond"], key="exp_time_unit")
            compression_sign = st.radio(
                "Compression convention",
                ["Positive compression", "Negative compression"],
                horizontal=True,
                key="compression_sign",
            )

            if analysis_mode == "Bar strain gauges":
                eps_i_col = choose_column("Incident strain column", columns, "eps_i")
                eps_r_col = choose_column("Reflected strain column", columns, "eps_r")
                eps_t_col = choose_column("Transmitted strain column", columns, "eps_t")
                strain_unit = st.selectbox("Gauge strain unit", ["microstrain", "strain"], key="strain_unit")
                reduction = st.selectbox(
                    "Stress reduction",
                    ["Three-wave average", "Transmitted-wave only"],
                    key="reduction_mode",
                )
            else:
                strain_col = choose_column("Strain column", columns, "direct_strain")
                stress_col = choose_column("Stress column", columns, "direct_stress")
                stress_unit = st.selectbox("Stress unit", ["MPa", "Pa"], key="direct_stress_unit")
                strain_unit = st.selectbox("Strain unit", ["strain", "percent", "microstrain"], key="direct_strain_unit")

        time = pd.to_numeric(df_raw[time_col], errors="coerce").to_numpy(dtype=float)
        if time_unit == "microsecond":
            time_s = time * 1e-6
            time_us = time
        elif time_unit == "millisecond":
            time_s = time * 1e-3
            time_us = time * 1e3
        else:
            time_s = time
            time_us = time * 1e6

        order = np.argsort(time_s)
        time_s = time_s[order]
        time_us = time_us[order]

        sign = 1.0 if compression_sign == "Positive compression" else -1.0
        Eb = bar_E_GPa * 1e9
        Ab = (0.050 * 0.050) if square_bar else np.pi * (bar_d_mm * 1e-3 / 2.0) ** 2
        if specimen_shape == "Square/cube":
            As = (specimen_side_mm * 1e-3) ** 2
        else:
            As = np.pi * (specimen_side_mm * 1e-3 / 2.0) ** 2
        Ls = specimen_length_mm * 1e-3

        if analysis_mode == "Bar strain gauges":
            scale = 1e-6 if strain_unit == "microstrain" else 1.0
            eps_i = sign * pd.to_numeric(df_raw[eps_i_col], errors="coerce").to_numpy(dtype=float)[order] * scale
            eps_r = sign * pd.to_numeric(df_raw[eps_r_col], errors="coerce").to_numpy(dtype=float)[order] * scale
            eps_t = sign * pd.to_numeric(df_raw[eps_t_col], errors="coerce").to_numpy(dtype=float)[order] * scale

            if reduction == "Three-wave average":
                stress_pa = Eb * Ab / (2.0 * As) * (eps_i + eps_r + eps_t)
            else:
                stress_pa = Eb * Ab / As * eps_t

            strain_rate = bar_C0 / Ls * (eps_i - eps_r - eps_t)
            strain = cumulative_trapezoid(strain_rate, time_s)

            energy_i = Ab * Eb * bar_C0 * cumulative_trapezoid(eps_i**2, time_s)
            energy_r = Ab * Eb * bar_C0 * cumulative_trapezoid(eps_r**2, time_s)
            energy_t = Ab * Eb * bar_C0 * cumulative_trapezoid(eps_t**2, time_s)
            absorbed = energy_i - energy_r - energy_t

            out = pd.DataFrame(
                {
                    "time_us": time_us,
                    "eps_incident": eps_i,
                    "eps_reflected": eps_r,
                    "eps_transmitted": eps_t,
                    "stress_MPa": stress_pa / 1e6,
                    "strain": strain,
                    "strain_rate_s-1": strain_rate,
                    "energy_incident_J": energy_i,
                    "energy_reflected_J": energy_r,
                    "energy_transmitted_J": energy_t,
                    "energy_absorbed_J": absorbed,
                }
            )
        else:
            raw_strain = sign * pd.to_numeric(df_raw[strain_col], errors="coerce").to_numpy(dtype=float)[order]
            if strain_unit == "percent":
                strain = raw_strain / 100.0
            elif strain_unit == "microstrain":
                strain = raw_strain * 1e-6
            else:
                strain = raw_strain
            raw_stress = sign * pd.to_numeric(df_raw[stress_col], errors="coerce").to_numpy(dtype=float)[order]
            stress_mpa = raw_stress if stress_unit == "MPa" else raw_stress / 1e6
            strain_rate = np.gradient(strain, time_s)
            out = pd.DataFrame(
                {
                    "time_us": time_us,
                    "stress_MPa": stress_mpa,
                    "strain": strain,
                    "strain_rate_s-1": strain_rate,
                }
            )

    out = out.replace([np.inf, -np.inf], np.nan).dropna(subset=["time_us", "stress_MPa", "strain"])
    st.session_state["tri_hb_reduced_data"] = out
    st.session_state["tri_hb_reduced_source"] = analysis_mode

    if out.empty:
        st.error("No valid reduced rows were produced. Check the selected columns and units.")
        return

    with col_plot:
        st.subheader("Reduced curves")
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Peak stress", f"{out['stress_MPa'].max():.1f} MPa")
        m2.metric("Peak strain", f"{100.0 * out['strain'].max():.3f} %")
        m3.metric("Peak strain rate", f"{out['strain_rate_s-1'].abs().max():.0f} /s")
        if "energy_absorbed_J" in out:
            m4.metric("Absorbed energy", f"{out['energy_absorbed_J'].iloc[-1]:.2f} J")
        else:
            m4.metric("Rows", f"{len(out):,}")

        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=100.0 * out["strain"],
                y=out["stress_MPa"],
                mode="lines",
                name="stress-strain",
                line=dict(width=3),
            )
        )
        fig.update_layout(
            height=390,
            xaxis_title="Strain (%)",
            yaxis_title="Stress (MPa)",
            margin=dict(l=55, r=20, t=15, b=50),
        )
        st.plotly_chart(fig, use_container_width=True)

    tabs = st.tabs(["Time histories", "Energy", "Export"])
    with tabs[0]:
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=out["time_us"], y=out["stress_MPa"], name="stress (MPa)"))
        fig.add_trace(go.Scatter(x=out["time_us"], y=out["strain_rate_s-1"], name="strain rate (/s)", yaxis="y2"))
        fig.update_layout(
            height=430,
            xaxis_title="Time (us)",
            yaxis=dict(title="Stress (MPa)"),
            yaxis2=dict(title="Strain rate (/s)", overlaying="y", side="right"),
            margin=dict(l=55, r=55, t=20, b=50),
        )
        st.plotly_chart(fig, use_container_width=True)

    with tabs[1]:
        if "energy_absorbed_J" not in out:
            st.info("Energy histories require incident, reflected and transmitted bar strain gauges.")
        else:
            if analysis_mode == "Simulator result":
                st.caption(
                    "Simulator energy histories use a closed budget: reflected, transmitted, and absorbed "
                    "energy are constrained by the available incident energy."
                )
            elif np.nanmax(out["energy_transmitted_J"] - out["energy_incident_J"]) > 1e-9:
                st.warning(
                    "Transmitted energy exceeds incident energy in the uploaded data. Check gauge signs, "
                    "units, bar area, wave-speed settings, and signal alignment."
                )
            fig = go.Figure()
            for col, label in [
                ("energy_incident_J", "Incident"),
                ("energy_reflected_J", "Reflected"),
                ("energy_transmitted_J", "Transmitted"),
                ("energy_absorbed_J", "Absorbed"),
            ]:
                fig.add_trace(go.Scatter(x=out["time_us"], y=out[col], name=label))
            fig.update_layout(
                height=430,
                xaxis_title="Time (us)",
                yaxis_title="Energy (J)",
                margin=dict(l=55, r=20, t=20, b=50),
            )
            st.plotly_chart(fig, use_container_width=True)

    with tabs[2]:
        st.dataframe(out.head(50), use_container_width=True)
        st.download_button(
            "Download reduced data",
            data=out.to_csv(index=False).encode("utf-8"),
            file_name="tri_hb_experimental_reduced.csv",
            mime="text/csv",
        )
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            out.to_excel(writer, index=False, sheet_name="Reduced data")
            df_raw.to_excel(writer, index=False, sheet_name="Raw upload")
        st.download_button(
            "Download workbook",
            data=buf.getvalue(),
            file_name="tri_hb_experimental_reduced.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )


def overview_page() -> None:
    st.markdown("# Tri-HB Integrated Workspace")
    st.caption("Testing design, experimental data reduction, stress-wave interpretation, and DEM-oriented damage validation.")

    st.markdown(
        """
        Use the sidebar to move through the unified workflow:

        1. **Test design and simulator** supports loading-mode design and stress-strain prediction.
        2. **Experimental data analysis** reduces bar-gauge or direct stress-strain files, or uses the latest Step 1 result directly.
        3. **Step 3: Waves, damage and validation** uses a guided layout by default, with advanced damage and failure-surface constants hidden until needed.
        """
    )

    c1, c2, c3 = st.columns(3)
    c1.metric("Design modes", "4")
    c2.metric("Workflow pages", "3")
    c3.metric("Experimental reducer", "CSV/XLSX")

    st.info("Start with test design, then reduce experimental data and review wave, damage, energy, and validation outputs in the combined workspace.")


page = st.sidebar.radio(
    "Tri-HB workspace",
    [
        "Overview",
        "Test design and simulator",
        "Experimental data analysis",
        "Step 3: Waves, damage & validation",
    ],
)

if page == "Overview":
    overview_page()
elif page == "Test design and simulator":
    run_legacy_app("Tri-HB.py")
elif page == "Experimental data analysis":
    experimental_analysis_page()
elif page == "Step 3: Waves, damage & validation":
    run_legacy_app("wave_damage.py")
